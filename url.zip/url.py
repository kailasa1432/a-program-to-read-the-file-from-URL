# In[ ]:


import requests
url = input("Enter the URL : ")
r = requests.get(url)
print(r.text)
